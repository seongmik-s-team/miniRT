# miniRT
MiniRT - Raytracing engine written in C
